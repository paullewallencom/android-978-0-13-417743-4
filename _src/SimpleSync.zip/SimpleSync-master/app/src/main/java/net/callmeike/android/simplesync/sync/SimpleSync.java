/* $Id: $
   Copyright 2012, G. Blake Meike

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
package net.callmeike.android.simplesync.sync;

import android.content.ContentProviderClient;
import android.content.ContentValues;
import android.net.Uri;
import android.os.RemoteException;

import java.io.IOException;
import java.util.List;

import com.squareup.okhttp.HttpUrl;

import net.callmeike.android.simplesync.data.SyncContract;
import net.callmeike.android.simplesync.data.SyncProvider;
import net.callmeike.android.simplesync.net.DaggerNetComponent;
import net.callmeike.android.simplesync.net.NetModule;
import net.callmeike.android.simplesync.net.RestService;


/**
 * @author <a href="mailto:blake.meike@gmail.com">G. Blake Meike</a>
 * @version $Revision: $
 */
class SimpleSync {
    private static final Uri CONTENT_URI = SyncContract.URI.buildUpon()
        .appendQueryParameter(SyncProvider.SYNC_UPDATE, "true")
        .build();

    public int sync(String url, ContentProviderClient provider) throws IOException, RemoteException {
        RestService restService = DaggerNetComponent.builder()
            .netModule(new NetModule(HttpUrl.parse(url)))
            .build()
            .restService();

        List<ContentValues> data = restService.loadData().execute().body();
        if (null == data) { return 0; }

        int len = data.size();
        if (len <= 0) { return 0; }

        ContentValues[] recs = new ContentValues[len];
        data.toArray(recs);

        return provider.bulkInsert(CONTENT_URI, recs);
    }
}
